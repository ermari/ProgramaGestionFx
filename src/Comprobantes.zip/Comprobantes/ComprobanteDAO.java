package Comprobantes;

import BD.BDconexion;
import Catalogo.Catalogo;
import Catalogo.CatalogoDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ComprobanteDAO {

    private CatalogoDAO cuentaDAO = new CatalogoDAO(); // Para obtener los objetos Cuenta

    public void saveComprobante(Comprobante comprobante) throws SQLException {
        String insertComprobanteSQL = "INSERT INTO comprobantes (fecha, numero_comprobante, concepto) VALUES (?, ?, ?)";
        String insertDetalleSQL = "INSERT INTO detalle_comprobantes (id_comprobante, id_cuenta, debito, credito, descripcion) VALUES (?, ?, ?, ?,?)";

        //PreparedStatement ps = BD.BDconexion.getInstance().getConnection().prepareStatement(sql);

        PreparedStatement stmtComprobante = null;
        PreparedStatement stmtDetalle = null;
        ResultSet rs = null;

        Connection conn = null;
        try {
            conn = BDconexion.getInstance().getConnection();
            conn.setAutoCommit(false); // Iniciar transacción

            // 1. Insertar el comprobante maestro
            stmtComprobante = conn.prepareStatement(insertComprobanteSQL, Statement.RETURN_GENERATED_KEYS);
            stmtComprobante.setDate(1, Date.valueOf(comprobante.getFecha()));
            stmtComprobante.setString(2, comprobante.getNumeroComprobante());
            stmtComprobante.setString(3, comprobante.getConcepto());
            stmtComprobante.executeUpdate();

            rs = stmtComprobante.getGeneratedKeys();
            int idComprobanteGenerado = 0;
            if (rs.next()) {
                idComprobanteGenerado = rs.getInt(1);
            } else {
                throw new SQLException("Error al obtener el ID del comprobante generado.");
            }
            comprobante.setIdComprobante(idComprobanteGenerado); // Asignar el ID generado al objeto

            // 2. Insertar los detalles del comprobante
            stmtDetalle = conn.prepareStatement(insertDetalleSQL);
            for (DetalleComprobante detalle : comprobante.getDetalles()) {
                stmtDetalle.setInt(1, idComprobanteGenerado);
                stmtDetalle.setInt(2, detalle.getContableCuenta().getCatalogoId());
                stmtDetalle.setDouble(3, detalle.getDebito());
                stmtDetalle.setDouble(4, detalle.getCredito());
                stmtDetalle.setString(5, detalle.getDescripcion());
                stmtDetalle.addBatch(); // Agregar al lote para inserción eficiente
            }
            stmtDetalle.executeBatch(); // Ejecutar todas las inserciones de detalle

            conn.commit(); // Confirmar la transacción
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback(); // Deshacer en caso de error
            }
            throw e; // Re-lanzar la excepción
        } finally {
            if (rs != null) rs.close();
            if (stmtComprobante != null) stmtComprobante.close();
            if (stmtDetalle != null) stmtDetalle.close();
            if (conn != null) conn.close();
        }
    }

    // Opcional: Método para cargar un comprobante con sus detalles (ejemplo)
    public Comprobante getComprobanteById(int idComprobante) throws SQLException {
        String selectComprobanteSQL = "SELECT id_comprobante, fecha, numero_comprobante, concepto FROM comprobantes WHERE id_comprobante = ?";
        String selectDetallesSQL = "SELECT id_detalle, id_cuenta, debito, credito FROM detalle_comprobantes WHERE id_comprobante = ?";

        Comprobante comprobante = null;
        try (Connection conn =BDconexion.getInstance().getConnection()){
            // Cargar el comprobante maestro
            try (PreparedStatement stmt = conn.prepareStatement(selectComprobanteSQL)) {
                stmt.setInt(1, idComprobante);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        comprobante = new Comprobante(
                                rs.getInt("id_comprobante"),
                                rs.getDate("fecha").toLocalDate(),
                                rs.getString("numero_comprobante"),
                                rs.getString("concepto")
                        );
                    }
                }
            }

            // Cargar los detalles si el comprobante existe
            if (comprobante != null) {
                List<DetalleComprobante> detalles = new ArrayList<>();
                try (PreparedStatement stmt = conn.prepareStatement(selectDetallesSQL)) {
                    stmt.setInt(1, idComprobante);
                    try (ResultSet rs = stmt.executeQuery()) {
                        while (rs.next()) {
                            int idCuenta = rs.getInt("id_cuenta");
                            Catalogo cuenta = cuentaDAO.getPorId(idCuenta); // Obtener la cuenta por ID
                            if (cuenta == null) {
                                // Manejar el error: cuenta no encontrada (ej. log, lanzar excepción)
                                System.err.println("Advertencia: Cuenta con ID " + idCuenta + " no encontrada para el detalle " + rs.getInt("id_detalle"));
                                continue;
                            }
                            DetalleComprobante detalle = new DetalleComprobante(
                                    rs.getInt("id_detalle"),
                                    idComprobante,
                                    cuenta,
                                    rs.getDouble("debito"),
                                    rs.getDouble("credito"),
                                    rs.getString("descripcion")
                            );
                                   detalles.add(detalle);
                        }
                    }
                }
                comprobante.setDetalles(detalles);
            }
        }
        return comprobante;
    }
}